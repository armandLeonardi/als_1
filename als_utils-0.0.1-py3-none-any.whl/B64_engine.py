import base64
from argparse import ArgumentParser

class B64_engine:

    def __init__(self, coding="utf8"):
        self.__version__ = "1.0.0"
        self.coding = coding

    def encode(self, string):
        encoded_string = string.encode(self.coding)
        encoded_b64_string = base64.b64encode(encoded_string)
        b64_string = encoded_b64_string.decode(self.coding)
        return b64_string
    
    def decode(self, b64_string):
        encode_string = base64.b64decode(b64_string)
        string = encode_string.decode(self.coding)
        return string

if __name__ == "__main__":

    parser = ArgumentParser()
    parser.add_argument("-e", "--encode", help="string to encode in base 64", default="")
    parser.add_argument("-d", "--decode", help="string in base 64 to decode", default="")
    parser.add_argument("-c", "--coding", help="coding standard used.", default="utf8")

    args = parser.parse_args()
    string_to_encode = args.encode
    string_to_decode = args.decode
    coding = args.coding

    if string_to_encode != "":
        b64 = B64_engine(coding=coding)
        string_b64 = b64.encode(string_to_encode)

        print("\n---------------")
        print(string_b64)
        print("---------------\n")

    elif string_to_decode != "":
        b64 = B64_engine(coding=coding)
        string = b64.decode(string_to_decode)

        print("\n---------------")
        print(string)
        print("---------------\n")
