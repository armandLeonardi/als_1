import json
from datetime import datetime
from colorama import init
from termcolor import colored
from datetime import datetime


class Message():
    """
    Codes:
    10: debug
    20: info
    30: warning
    40: error
    """

    def __init__(self, code, message, date_format = "%m/%d/%Y %H:%M:%S"):

        self.__version__ = "1.0.0"
        self.message = message
        self.date_format = date_format

        # init coloration
        init()

        if code not in [10, 20, 30, 40]:
            code = 20

        if code == 10: # debug
            self.color = 'cyan'
            self.code = "debug"
        elif code == 20: # info
            self.color = 'white'
            self.code = "info"
        elif code == 30: # warning
            self.color = "yellow"
            self.code = "warning"
        elif code == 40: # error
            self.color = 'red'
            self.code = "error"

    def __repr__(self):
        _message = self.format_message(self.code, self.message)
        return colored(_message, self.color)

    def now(self):
        return datetime.now().strftime(self.date_format)

    def format_message(self, code, message):
        return "{time} | {code: <7} | {message}".format(time=self.now(), code=code, message=message)


class Kernel:
    """Class use to provide same basic funcitonalities to all al-s classes.
    """

    def __init__(self, config_path="", verbose=False, debug=False, heritate_class=""):
        self.__version__ = "1.0.1"
        self.config_path = config_path
        self.verbose = verbose
        self.debug = debug
        self.heritate_class = heritate_class if heritate_class != "" else self.__class__.__name__
        self.encoding = "utf8"

    def display(self, message, end="\n"):

        if message.code == "debug" and self.debug:
            print(message, end=end)

        if message.code != "debug" and self.verbose:
            print(message, end=end)

    def now(self):
        return datetime.now().strftime(self.date_format)

    def load_json(self, path):

        content = ""
        if ".json" in path:
            try:
                with open(path, 'r', encoding=self.encoding) as f:
                    content = json.load(f)

                message = Message(10, 'load json successfull')
            except Exception as error:
                message = Message(40, error)
        else:
            message = Message(30, "Given path is not a json file")

        self.display(message)

        return content

    def write_json(self, file_name, content):

        if ".json" in file_name:
            try:
                with open(file_name, "w", encoding=self.encoding) as f:
                    json.dump(content, f)

                message = Message(10, 'writing json successfull')
            except Exception as error:
                message = Message(40, error)
        else:
            message = Message(30, "Given path is not a json file")

        self.display(message)
    
    def load_config(self):

        config = {}
        config = self.load_json(self.config_path)

        return config

if __name__== "__main__":

    # Messages demo part
    m10 = Message(10, "debug message")
    print(m10)

    m20 = Message(20, "info message")
    print(m20)

    m30 = Message(30, "warning message")
    print(m30)

    m40 = Message(40, "error message")
    print(m40)
