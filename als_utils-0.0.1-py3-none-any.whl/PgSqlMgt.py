import psycopg2
from B64_engine import B64_engine
from Kernel import Message


class PgSqlMgt:

    def __init__(self, host, port, user, password, encoded, database):
        self.__version__ = "1.0.1"
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.encoded = encoded
        self.conn = None
        self.cur = None

    def connect(self):
        try:

            if self.encoded:
                b64 = B64_engine()
                password = b64.decode(self.password)
            else:
                password = self.password

            self.conn = psycopg2.connect(host=self.host,
                                        port=self.port,
                                        user=self.user,
                                        password=password,
                                        database=self.database)
            self.cur = self.conn.cursor()
        except Exception as err:
            message = Message(40, err)
            raise print(message)

    def version(self):
        out = self.cur.execute("SELECT VERSION();")
        out = self.cur.fetchall()
        return out

    def select(self, query):
        out = []

        if self.conn is None:
            self.connect()

        try:
            self.cur.execute(query)
            out = self.cur.fetchall()
        except Exception as err:
            print(err)
            
        return out

    def insert(self, query):
        out = []

        if self.conn is None:
            self.connect()

        try:
            self.cur.execute(query)
        except Exception as err:
            print(err)
            
        return out
    
    def commit(self):
        self.cur.execute("commit")

    def close(self):
        self.cur.close()
        self.conn.close()

        self.cur = None
        self.conn = None